# پچ ۶۰-د — نشانگر هویت کاربر واردشده در سایدبار

> تاریخ: 2026-11-22 · زمینه: دیتابیس و کد دسترسی‌ها درست بودند؛ نشستِ مرورگرِ تست
> در واقع مالک بود نه c2 — سایدبارِ کامل مالِ مالک است. برای اینکه دیگر این اشتباه
> رخ ندهد، همیشه «👤 ایمیل» کاربرِ واردشده در پایین سایدبار دیده می‌شود.

## تغییر

| فایل | تغییر |
| --- | --- |
| `lib/admin/roles.ts` | getOperatorRole حالا email را هم برمی‌گرداند |
| `app/api/admin/whoami/route.ts` | پاسخ شامل email شد |
| `app/admin/layout.tsx` | «👤 ایمیل» در پایین سایدبار و drawer |

## نصب

`patch-60d-whoami-badge.zip` را روی ریشهٔ پروژه Extract کن (Replace → بله):

```powershell
git add -A
git commit -m "60d: show signed-in email in sidebar (session identity badge)"
git push
```

## تست تعیین‌کنندهٔ نشست (بدون نیاز به دیپلوی — همین حالا)

در همان پنجرهٔ ناشناسی که فکر می‌کنی c2 هستی، این آدرس را باز کن:

```
https://cafe-park-menu.vercel.app/api/admin/whoami
```

- `{"role":"owner",...}` → نشست مالک است! دکمهٔ «خروج» را بزن و با c2 وارد شو
  (رمز درست). اگر رمز c2 را نمی‌دانی: Supabase → Authentication → Users →
  کاربر c2 → «Send password recovery».
- `{"role":"cashier","paths":[...]}` → نشست واقعاً c2 است و باید منو فیلتر شود؛
  اگر دیدی و باز هم منو کامل بود، JSON را برای من بفرست.
- خطا/خالی → JSON را بفرست.

## چک بهداشتی env (یک‌بار)

Vercel → پروژه → Settings → Environment Variables → `ADMIN_EMAILS` باید فقط
ایمیل مالک باشد (مثلاً `hadiassadi@gmail.com`). اگر c2@cafepark.com در آن است،
حذفش کن و redeploy — هر ایمیلِ آن لیست از گیت پروکسی کامل عبور می‌کند.
